 var config = {
    apiKey: "AIzaSyBGmfVmifV69sr_mGhOh7LbKqKm7mkVNCg",
    authDomain: "firechat-99aff.firebaseapp.com",
    databaseURL: "https://firechat-99aff.firebaseio.com",
    projectId: "firechat-99aff",
    storageBucket: "firechat-99aff.appspot.com",
    messagingSenderId: "67692431371"
  };
  firebase.initializeApp(config);
