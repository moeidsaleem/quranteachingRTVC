<?php
//-----------------------------CONNECTION------------------------//

$con = mysqli_connect ("localhost","root","","rajajbqa_onlinequran");

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX END XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX//
?>