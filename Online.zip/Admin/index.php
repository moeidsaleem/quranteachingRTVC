<?php 
    session_start();
    if(isset($_GET["logmeout"])){
        session_destroy();
        $_SESSION["ADMIN_PANEL"] = false;
        echo "<script>alert('LOG OUT SUCCESSFULLY');</script>";
        echo "<script> window.location='index.php' </script>";
    }
?>

<!DOCTYPE html>
<html>
    <head>
    <title>Admin Login</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/main.css" rel="stylesheet" />
    </head>
    <body>
        <div class="container">
            <div class="row">
                <form method="post" class="form-login">
                    <h2>Admin Panel.</h2>
                    <input type="text" id="userName" name="txtUsername" class="form-control input-lg chat-input" placeholder="username" />
                    <br>
                    <input type="password" id="userPassword" name="txtPass" class="form-control input-lg chat-input" placeholder="password" />
                    <br>
                    <div class="wrapper">
                        <span class="group-btn">     
                            <button type="submit" name="btn" class="btn btn-primary btn-lg btn-width">login <i class="fa fa-sign-in"></i></button>
                        </span>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>

<?php

//----------------------------- ADMIN BUTTON-------------------------------//
if(isset($_POST['btn']))
{
    $username = $_POST['txtUsername'];
    $password = $_POST['txtPass'];
    
    if($username == 'admin' && $password == 'admin')
    {
        $_SESSION["ADMIN_PANEL"] = "Admin";
        echo "<script> window.location='home.php' </script>";
    }   
    else
    {
        echo "<script> alert('INVALID') </script>";
        echo "<script> window.location='index.php' </script>";
    }
    
}
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX END XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX//
?>