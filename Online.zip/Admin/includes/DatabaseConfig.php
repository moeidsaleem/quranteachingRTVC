<?php
//-----------------------------CONNECTION------------------------//

$con = mysqli_connect ("213.171.200.97","rajajbqa","AbCdEfGhiJkL111@@@","rajajbqa_onlinequran");

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX END XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX//
?>